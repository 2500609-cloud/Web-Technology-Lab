// Define Interface
interface Employee {
    id: number;
    name: string;
    salary: number;

    displayInfo(): void;
}

// Implement Interface in Class
class EmployeeDetails implements Employee {
    id: number;
    name: string;
    salary: number;

    constructor(id: number, name: string, salary: number) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    displayInfo(): void {
        console.log("Employee ID: " + this.id);
        console.log("Name: " + this.name);
        console.log("Salary: " + this.salary);
    }
}

// Create Object
let emp1 = new EmployeeDetails(1, "Ali", 50000);

// Call Method
emp1.displayInfo();