interface Employee {
    id: number;
    name: string;
    salary: number;
}
let emp = {} as Employee;
emp.id = 101;
emp.name = "Ali";
emp.salary = 60000;
console.log(emp);