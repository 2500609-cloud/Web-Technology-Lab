const fs = require('fs');

const studentData = "Name: Umar\nCourse: BSCS";

fs.writeFileSync('student.txt', studentData);

const data = fs.readFileSync('student.txt', 'utf8');
console.log(data);