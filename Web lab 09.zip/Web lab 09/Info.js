console.log("Name: Umar Sarfraz");
console.log("Course: ADSCS-2A");
console.log("University: Air University");

