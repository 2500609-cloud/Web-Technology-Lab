const http = require('http');

const server = http.createServer((req, res) => {

    if (req.url === '/api') {
        const student = {
            name: "Ali",
            course: "BSCS"
        };

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(student));
    }
    else {
        res.write("Other Route");
        res.end();
    }

});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});